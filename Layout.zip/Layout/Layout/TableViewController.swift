//
//  TableViewController.swift
//  Layout
//
//  Created by user213614 on 3/22/22.
//

import UIKit

class TableViewController: UITableViewController{
    
    let pizza: [String] = ["Mucarela", "Calabreza", "Frango"]
    
    let descricaoPizza = ["Pizza com queijo mucarela", "Pizza com rodelas de calabreza", "Pizza com frango desfiado	"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func numberOfSections(in tableView: UITableView) -> Int { //numero de colunas
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pizza.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let celula = tableView.dequeueReusableCell(withIdentifier: "celulaReuso", for: indexPath)//
        
        celula.textLabel?.text = pizza[indexPath.row] //bota o texto em cada celula
        
        
        return celula
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
     //   segundaTela.navigationController?.popViewController(animated: true)
    }
}
